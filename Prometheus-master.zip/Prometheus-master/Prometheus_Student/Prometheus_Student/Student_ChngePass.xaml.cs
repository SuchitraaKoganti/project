﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for Student_ChngePass.xaml
    /// </summary>
    public partial class Student_ChngePass : Window
    {
        public Student_ChngePass()
        {
            InitializeComponent();
        }
    }
}
