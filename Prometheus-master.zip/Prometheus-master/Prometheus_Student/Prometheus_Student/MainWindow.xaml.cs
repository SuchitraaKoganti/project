﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }

       
        private void btn_UpdateInfo_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_Info>().Any())
            {
                Student_Info stu = new Student_Info();
                stu.Show();
            }
        }

        private void btn_SubmitAssignment_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_SubAssign>().Any())
            {
                Student_SubAssign stuAssign = new Student_SubAssign();
                stuAssign.Show();
            }

        }

        private void btn_homework_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_HwAssgned>().Any())
            {
                Student_HwAssgned shwa = new Student_HwAssgned();
                shwa.Show();
            }
        }

        public DataTable LoadDeparment()
        {
            SqlConnection conn = new SqlConnection("Data Source=ndamssql\\sqlilearn;Initial Catalog=Sep19CHN;User ID=sqluser;Password=sqluser");
            DataTable dtDept = new DataTable();
            SqlCommand empCommand = new SqlCommand("Group1.usp_DisplayCourses", conn);
            empCommand.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader empReader = empCommand.ExecuteReader();
            dtDept.Load(empReader);
            return dtDept;
        }

        private void btn_Enroll_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enrolled for the course:  "+cmb_Courses.Text);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MainWindow validationObj = new MainWindow();
            DataTable dtDept = validationObj.LoadDeparment();
            if (dtDept.Rows.Count >= 0)
            {
                cmb_Courses.ItemsSource = dtDept.DefaultView;

                cmb_Courses.DisplayMemberPath = "CourseName";
                cmb_Courses.SelectedValuePath = "CourseID";
            }
        }
    }
}

