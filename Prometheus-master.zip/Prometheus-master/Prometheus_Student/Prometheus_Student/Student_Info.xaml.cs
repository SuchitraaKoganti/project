﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for Student_Info.xaml
    /// </summary>
    public partial class Student_Info : Window
    {
        public Student_Info()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnchangepass_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_ChngePass>().Any())
            {
                Student_ChngePass change = new Student_ChngePass();
                change.Show();
            }
        }
    }
}
