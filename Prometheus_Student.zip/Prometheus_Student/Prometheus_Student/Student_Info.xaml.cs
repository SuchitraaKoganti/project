﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Stu.Entity;
using Stu.Exception;
using Stu.BL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Stu.DAL;

namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for Student_Info.xaml
    /// </summary>
    public partial class Student_Info : Window
    {
       

        public Student_Info()
        {
            InitializeComponent();
           
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnchangepass_Click(object sender, RoutedEventArgs e)
        {
            if (!Application.Current.Windows.OfType<Student_ChngePass>().Any())
            {
                Student_ChngePass change = new Student_ChngePass();
                change.Show();
            }
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            //SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Sep19CHN"].ConnectionString);
            //SqlCommand cmd = new SqlCommand();
            StudentValidation student = new StudentValidation();
            
            try
            {

                Student stud = new Student();

                stud.StudentID = Convert.ToInt32(txtStudID.Text);
                stud.FName = txtStudfName.Text;
                stud.LName = txtStudLName.Text;
                stud.Address = txtStudAddr.Text;
                stud.DOB = Convert.ToDateTime(dpStudDOB.Text);
                stud.City = txtStudCity.Text;
                stud.MobileNo = Convert.ToInt64(txtStudPhno.Text);


                
                int recordsAffected = student.updateTeacher_BLL(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();

                }
                else
                    throw new StudentException("Record not updated");

            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

      
         
           
           
        }

        
    }

