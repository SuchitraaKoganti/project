﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;



namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for Student_HwAssgned.xaml
    /// </summary>
    public partial class Student_HwAssgned : Window
    {
        public Student_HwAssgned()
        {
            InitializeComponent();
        }

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {


            try
            {
                if (dataGrid1.Items.Count > 0)
                {
                    // checking whether listbix1 has items or not if yes then moving items
                    dataGrid2.Items.Add(dataGrid1.SelectedItem.ToString());
                    dataGrid1.Items.Remove(dataGrid1.SelectedItem);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //selecting first item of dataGrid.
            if (dataGrid1.Items.Count > 0)
                dataGrid1.SelectedIndex = 0;
            dataGrid2.SelectedIndex = dataGrid2.Items.Count - 1;
        }

        private void btn_AddAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //moving all items from dataGrid1 to dataGrid2
                dataGrid2.Items.Add(dataGrid1.Items);
                dataGrid1.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            dataGrid2.SelectedIndex = 0;
        }

        private void btn_Remove_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dataGrid2.Items.Count > 0)
                {
                    //checking whether dataGrid2 has items or not. If yes then moving
                    //selected item from dataGrid2 to dataGrid1
                    dataGrid1.Items.Add(dataGrid2.SelectedItem.ToString());
                    dataGrid2.Items.Remove(dataGrid2.SelectedItem);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            if (dataGrid2.Items.Count > 0)
                dataGrid2.SelectedIndex = 0;
            dataGrid1.SelectedIndex = dataGrid1.Items.Count - 1;

        }

            private void btn_RemoveAll_Click(object sender, RoutedEventArgs e)
            {
                try
                {
                //moving all items from dataGrid2 to dataGrid1
                dataGrid1.Items.Add(dataGrid2.Items);
                dataGrid2.Items.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                dataGrid1.SelectedIndex = 0;
            }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            //Sep19CHN contextObj = new Sep19CHN();


            //var query = from Homework hw in contextObj.Homework

            //            select hw;

            //List<Homework> eList = new List<Prometheus_Student.Homework>();
            //eList = query.ToList<Homework>();


            //if (eList.Count <= 0)
            //{
            //    MessageBox.Show("No records Found");
            //}
            //else
            //{
            //    dataGrid1.ItemsSource= query.ToList();
            //}


            
        }
    }
}
