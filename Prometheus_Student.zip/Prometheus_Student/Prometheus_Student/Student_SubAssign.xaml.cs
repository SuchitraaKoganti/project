﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Prometheus_Student
{
    /// <summary>
    /// Interaction logic for Student_SubAssign.xaml
    /// </summary>
    public partial class Student_SubAssign : Window
    {
        public Student_SubAssign()
        {
            InitializeComponent();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txt_Assignment.Text = ofd.FileName;
            }
        }

        private void button_Click_1(object sender, RoutedEventArgs e)
        {
            if (txt_Assignment.Text == string.Empty)
            {
                MessageBox.Show("Invalid Upload");
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("Assignment Uploaded Successfully", "Confirmation");
            }
            txt_Assignment.Clear();
        }
    }
}

    