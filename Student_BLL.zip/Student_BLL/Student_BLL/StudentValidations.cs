﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Student_BLL
{
    class StudentValidations
    {
        Sep19CHNEntities obj = new Sep19CHNEntities();
        //Method to validate Student details
        public static bool ValidateStudent(Student stud)
        {
            bool isValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (stud.FName == string.Empty)
                {
                    message.Append("Student First Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(stud.FName, "[A-Z][a-z]{2,}"))
                {
                    message.Append("Student first Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidated = false;
                }
                //To validate Last name
                if (stud.LName == string.Empty)
                {
                    message.Append("Student Last Name should be provided\n");
                    isValidated = false;
                }
                else if (!Regex.IsMatch(stud.LName, "[A-Z][a-z]{2,}"))
                {
                    message.Append("Student Last Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValidated = false;
                }
                //To validate address
                if (stud.Address == string.Empty)
                {
                    message.Append("Student Address should be provided\n");
                    isValidated = false;
                }
                //To  validate date of birth
                int age = DateTime.Now.Year - stud.DOB.Year;
                if (age < 18 || age > 25)
                {
                    message.Append("Date of Birth should be proper so that student age will be in range from 04 to 15\n");
                    isValidated = false;
                }
                //To validate city
                if (stud.City == string.Empty)
                {
                    message.Append("Student City should be provided\n");
                    isValidated = false;
                }
                //Checking Phone Number
                if (!Regex.IsMatch(Convert.ToString(stud.MobileNo), "[0-9]{10}"))
                {
                    message.Append("Phone number should have exactly 10 digits\n");
                    isValidated = false;
                }
                //Checking Password
                var input = "P@ssw0rd";

                var hasNumber = new Regex(@"[0-9]+");
                var hasUpperChar = new Regex(@"[A-Z]+");
                var hasMinimum8Chars = new Regex(@".{8,}");

                if (!hasNumber.IsMatch(input) && hasUpperChar.IsMatch(input) && hasMinimum8Chars.IsMatch(input))
                {
                    message.Append("Password should have 1 Uppercase, a number and it should be minimum of 8 characetrs\n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isValidated;
        }
    }
}
